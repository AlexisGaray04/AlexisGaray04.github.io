Alexis Garay, R11968342

Media Product/Service Landing Page

I am developing a social media platform landing page for my CMI 3315 Intro to Web Design class. 
My inspirations will come from retro social media websites such as SixDegrees, [thefacebook], and Myspace, while taking notes on retro-inspired takes on social media, such as SpaceHey and the now defunct Cohost.

Features implemented...
In the service itself, would have custom profiles (editable with CSS)
Servers (Would be considered Galaxies)
Groups that connect said servers (Would be considered Galaxy Clusters)
Timeline (akin to Bluesky and X (formerly known as Twitter))
No personalized ads, no tracking, no algorithms, would primarily run on donations
Storage space, emphasis on archivals

As for the landing page features...
Has animations
Uses flexbox quite often
Video in background
Hamburger when looked at using phone
Has Testimonials that appear like social media posts

Fonts used...
Inter
Open Sans
Arial
Sans-Serif

Color Palette...
https://www.color-hex.com/color-palette/28652
My Big Five Colors
   --main-color: #660094;
   --main-color-dark: #310047;
   --main-color-light: #d16aff;
   --secondary-color: #F9DC5C;
   --tertiary-color: #FB3640;

Everything Else
   --color-light-gray: #A6A6A6;
   --color-heading: #000000;
   --color-background-dark: #0a0a0a;
   --color-background: #ffffff;
   --color-background-alt: #fafafa;
   --color-surface: #f5f5f5;
   --color-border: #e5e5e5;
   --color-text-secondary: #666666;
   --color-text-muted: #999999;


Image sources...
https://pixabay.com/videos/stars-long-exposure-starry-sky-6962/
https://unsplash.com/photos/blue-and-purple-galaxy-digital-wallpaper-E0AHdsENmDg
https://fastly.picsum.photos/id/948/600/300.jpg?hmac=Qen6CZnyl2rVqGUeabImTAY9VWvLrTL6tKajIHyMiFM (Skyscraper)
https://fastly.picsum.photos/id/537/600/300.jpg?hmac=D-bgtZnrWU3KCgf8SccYa1XFRvLN9JnWD7fYjKIT_Cg (Shooting Star in a Starry Sky)
https://fastly.picsum.photos/id/1078/600/300.jpg?hmac=anS8qgzJR-KQXpJcEsPC_a1xF7yup1i3bTnak1pb1QE (Skyscraper at night with rooms turned on)
https://fastly.picsum.photos/id/101/600/300.jpg?hmac=nBfa97LfkHPXen3J36_zWZktMrx8wm7bDhhaTpUP6_8 (Fortress Rooftop)
I made the Starlight Logo myself. Vectorized with https://www.vectorizer.io/

Challenges...
This assignment was one of the most intense projects I've worked on in my 17 years of academia. Figuring out how to
apply the knowledge learned during class, repurposing it, configuring everything, maintaining a space aesthetic, was intense.
I made many compromises with the design of the website, and designing logos, choosing images, repurposing code, was painful.
This took around 10+ hours to complete. I used no AI.

Resources:
https://nekocalc.com/px-to-rem-converter
https://animista.net/
validator.w3.org
cssgridgenerator.io
ianlunn.github.io/Hover
Squoosh.com (free image compressor)
Unsplash.com (free images)
Pixabay.com (free images and videos)
Photopea.com (free online photo editor)
cssgradient.com
coolors.co
Alexis Garay, R11968342

Multi-Page News/Magazine Site

I am developing a news website framework for my CMI 3315 Intro to Web Design class. 
My inspirations are the websites for Reuters, the Associated Press, and the Houston Chronicle.
I go to the Reuters and Associated Press websites every day for my news, and so I went with them due to my familiarity.

I have the home page, which features various potential news articles (only one is clickable),
an article page (for Amtrak), a section page, an About Me page, and a Gallery page for the various photos I have. All the photos are mine.

Sketch Process:
I sketched all my images in one day. They were during the 12th of April. 
I based the sketches, on the aspects of the Reuters and APNews website that I enjoyed the most.


Fonts used...
Inter https://fonts.google.com/?query=inter
Arial
Sans-Serif

Color Palette...
My Main Colors
   --main-color: #EFBF04;
   --secondary-color: #ffdd53;

Everything Else
   --color-light-gray: #A6A6A6;
   --color-heading: #1a1a1a;
   --color-background-dark: #0a0a0a;
   --color-text: #2d2d2d;
   --color-background: #ffffff;
   --color-background-alt: #fafafa;
   --color-surface: #f5f5f5;
   --color-border: #e5e5e5;
   --color-text-secondary: #666666;
   --color-text-muted: #999999;


Image sources...
Me. I took these photos several years ago with my iPhone SE, from around 2023-2024.
The images were converted to WebP with https://cloudconvert.com/jpg-to-webp
I made the UC Logo myself. Vectorized with https://www.vectorizer.io/, made smaller with https://www.iloveimg.com/resize-image/resize-svg.

I did not really use any special techniques this time around. I did make certain to make the links grey out whenever the mouse scrolled over it.
Apologies for the lack of special gimmicks.

Challenges...
I used no AI, again. This assignment will likely not be up to your standards, as I had multiple (four) assignments due during the past weekend.
I started too late with this assignment. Since I am relying on a bunch of reused and modified code, I am uncertain just how unprofessional it will appear.
Apologies.
I was unable to do the photo gallery page.
Learning how to do this in quick time taught me to begin using the search function more, which was interesting. I will prepare more for the next assignment.

Resources:
https://nekocalc.com/px-to-rem-converter
https://animista.net/
validator.w3.org
cssgridgenerator.io
ianlunn.github.io/Hover
Squoosh.com (free image compressor)
Unsplash.com (free images)
Pixabay.com (free images and videos)
Photopea.com (free online photo editor)